
# Portfolio App (v1, Morocco Pack)
Projet React + Vite + TypeScript, PWA, prêt à être importé dans StackBlitz/CodeSandbox.
Ce ZIP est la version complète du monorepo décrite dans le chat.
